<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Times extends CI_Controller {
	

	public function main()
	{
		$this->load->view('time_view');
	}

}
